/* 
File: requestchannel.C

Author: R. Bettati
Department of Computer Science
Texas A&M University
Date  : 2012/07/11

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include <cassert>
#include <cstring>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <errno.h>

#include "reqchannel.h"

using namespace std;

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR FOR CLASS   R e q u e s t C h a n n e l  */
/*--------------------------------------------------------------------------*/


//Create a NetworkRequestChannel based on the given socket
 NetworkRequestChannel::NetworkRequestChannel(int socket){
	 
 }

//client
NetworkRequestChannel::NetworkRequestChannel(const string _server_host_name, const unsigned short _port_no) 
{  
}

//Constructor used in Server Side to Create Channel with Specific Port Number and back log.
NetworkRequestChannel::NetworkRequestChannel(const unsigned short _port_no, void * (*connection_handler) (void*), int back_log)
{  
	
	
}

//close socket
NetworkRequestChannel::~NetworkRequestChannel() 
{     

}

/*--------------------------------------------------------------------------*/
/* READ/WRITE FROM/TO REQUEST CHANNELS  */
/*--------------------------------------------------------------------------*/

const int MAX_MESSAGE = 255;

string NetworkRequestChannel::send_request(string _request) 
{
	
}

string NetworkRequestChannel::cread() 
{

}

int NetworkRequestChannel::cwrite(string _msg) 
{

}