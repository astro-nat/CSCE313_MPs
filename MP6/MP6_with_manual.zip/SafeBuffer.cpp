//
//  SafeBuffer.cpp
//
//
//  Created by Joshua Higginbotham on 11/4/15.
//
//

#include "SafeBuffer.h"
#include <string>
#include <queue>

SafeBuffer::SafeBuffer() {
	
}

SafeBuffer::~SafeBuffer() {
	
}

int SafeBuffer::size() {
    return 0;
}

void SafeBuffer::push_back(std::string str) {
	return;
}

std::string SafeBuffer::retrieve_front() {
	return "";
}
